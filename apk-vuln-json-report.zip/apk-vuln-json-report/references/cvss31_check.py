#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
cvss31_check.py — CVSS 3.1 评分一致性校验器（已用官方 cvss 库 v3.6 校准）

用途：APK 漏洞 JSON 报告生成后，用它对 score_value / risk_level / cia / vuln_class
做程序化复算校验，杜绝手算错误。

依赖：`pip install cvss`（Red Hat 官方 python-cvss，含 CVSS3.1 完整实现）。
      已在本环境验证：CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H → 9.8（正确）。

两种用法：
  1) 校验单个向量：  python3 cvss31_check.py "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N"
  2) 校验整批报告：  python3 cvss31_check.py /app/data/apk_vuln_json_reports
                     （逐文件检查 score_value/risk_level/cia-vs-vector/vuln_class/control-chars/impact）

退出码：0 = 全部通过；1 = 有问题。
"""
import sys, os, json, glob, math

# ---- 权威评分：优先官方 cvss 库（必需）。缺失时回退内置近似公式并【显著告警】。 ----
try:
    from cvss import CVSS3
    def libscore(v):
        return round(CVSS3(v).scores()[0], 1)
    SRC = "official-cvss-lib"
    _HAVE_LIB = True
except Exception:
    # 内置 CVSS 3.1 公式（S:U 与多数 S:C 向量与官方库一致；个别 S:C 边界可能差 0.1-0.4）。
    # 仅作应急回退：请 `pip install cvss` 后用官方库校验。
    W = {
        'AV': {'N': 0.85, 'L': 0.62, 'A': 0.55, 'P': 0.20},
        'AC': {'L': 0.77, 'H': 0.44},
        'PR_U': {'N': 0.85, 'L': 0.62, 'H': 0.27},
        'PR_C': {'N': 0.85, 'L': 0.68, 'H': 0.50},
        'UI':   {'N': 0.85, 'Y': 0.62},
        'CIA':  {'N': 0.0, 'L': 0.22, 'H': 0.56},
    }
    def roundup(x):
        return math.ceil(x * 10) / 10.0
    def libscore(v):
        body = v.split('CVSS:3.1/', 1)[1]
        p = {}
        for t in body.split('/'):
            if ':' in t:
                k, val = t.split(':', 1); p[k] = val
        iss = 1 - ((1 - W['CIA'][p['C']]) * (1 - W['CIA'][p['I']]) * (1 - W['CIA'][p['A']]))
        if iss < 0: iss = 0
        if p['S'] == 'U':
            impact = 6.42 * iss
        else:
            impact = 7.52 * (iss - 0.029) - 3.25 * (iss * 0.9731 + 0.019) ** 15
        pr_key = 'PR_U' if p['S'] == 'U' else 'PR_C'
        expl = 8.22 * W['AV'][p['AV']] * W['AC'][p['AC']] * W[pr_key][p['PR']] * W['UI'][p['UI']]
        if impact <= 0:
            return 0.0
        if p['S'] == 'U':
            base = roundup(impact + expl)
        else:
            base = roundup(1.08 * (impact + expl))
        # S:C 时官方库会 clamp 到 [0,10]
        if base > 10.0: base = 10.0
        return round(base, 1)
    SRC = "builtin-approx(官方库缺失,结果可能差0.1-0.4!请 pip install cvss)"
    _HAVE_LIB = False
    if hasattr(sys, 'stderr'):
        print("⚠️  未找到官方 cvss 库，回退内置近似公式。强烈建议: pip install cvss", file=sys.stderr)


def risk(s):
    return 'critical' if s >= 9 else 'high' if s >= 7 else 'medium' if s >= 4 else 'low' if s >= 0.1 else 'info'


def parse(vec):
    body = vec.split('CVSS:3.1/', 1)[1]; p = {}
    for t in body.split('/'):
        if ':' in t:
            k, v = t.split(':', 1); p[k] = v
    return p


ENUM = {'组件导出暴露','越权访问','Intent注入','DeepLink漏洞','WebView漏洞','JSBridge漏洞',
        '不安全网络通信','证书校验缺陷','硬编码敏感信息','不安全数据存储','加密算法误用',
        'Native内存破坏','代码注入·动态加载','第三方SDK漏洞','权限滥用','拒绝服务','供应链风险','其他'}


def check_vector(vec):
    lv = libscore(vec)
    p = parse(vec)
    return lv, p, risk(lv)


def check_file(f):
    bad = []
    d = json.load(open(f))
    s = d['severity'][0]
    vec = s['score']
    if not vec.startswith('CVSS:3.1/'):
        return [f"{f}: not CVSS:3.1"]
    lv, p, rl_expected = check_vector(vec)
    pds = d['database_specific']; cia = d['impact_scope']['cia']
    if abs(lv - s['score_value']) > 0.05:
        bad.append(f"score_value {s['score_value']} != 复算 {lv}")
    if pds['risk_level'] != rl_expected:
        bad.append(f"risk_level {pds['risk_level']} != 区间应为 {rl_expected} (score {lv})")
    if pds['vuln_class'] not in ENUM:
        bad.append(f"vuln_class '{pds['vuln_class']}' 非法枚举")
    for k in ('C', 'I', 'A'):
        if cia.get(k) != p.get(k):
            bad.append(f"cia.{k}={cia.get(k)} != 向量 {p.get(k)}")
    if not d['impact_scope']['impact_description']:
        bad.append("impact_description 为空")
    raw = open(f, 'rb').read()
    if any(b < 9 or (13 < b < 32) for b in raw if b != 10):
        bad.append("含控制字符(应仅 \\n 转义)")
    return [f"{f}: {b}" for b in bad]


def main():
    args = [a for a in sys.argv[1:]]
    if not args:
        print(__doc__); sys.exit(2)
    target = args[0]
    # 单向量模式
    if target.startswith('CVSS:3.1/'):
        lv, p, rl = check_vector(target)
        print(f"向量:   {target}")
        print(f"评分:   {lv}")
        print(f"risk_level 区间: {rl}")
        print(f"C/I/A = {p.get('C')}/{p.get('I')}/{p.get('A')},  S={p.get('S')}, UI={p.get('UI')}")
        print(f"(评分来源: {SRC})")
        sys.exit(0)
    # 目录批量模式
    files = sorted(glob.glob(os.path.join(target, '*.json')))
    if not files:
        print(f"在 {target} 下未找到 .json 文件"); sys.exit(2)
    total_bad = []
    for f in files:
        try:
            total_bad += check_file(f)
        except Exception as e:
            total_bad.append(f"{f}: 解析失败 {e}")
    print(f"校验 {len(files)} 个报告（评分来源: {SRC}）")
    if total_bad:
        print("发现问题:")
        for b in total_bad:
            print("  -", b)
        sys.exit(1)
    print("全部通过 ✓  score_value / risk_level / vuln_class / cia-vs-vector / impact / control-chars")
    sys.exit(0)


if __name__ == '__main__':
    main()

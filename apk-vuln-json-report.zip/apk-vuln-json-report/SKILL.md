---
name: apk-vuln-json-report
description: 【触发条件：APK 渗透/安全任务中确认高危及以上（high/critical）漏洞后必须调用本 skill】根据 APK 客户端及/或后端 API 的漏洞分析结果，生成严格符合《APK 漏洞 JSON 报告生成规范 v1.0.0》的单 JSON 对象报告，并保存到 /app/data/apk_vuln_json_reports/{MMDD}/（按报告生成日期分目录，如 0930/）。含标准字段模板、CWE 在线匹配(MITRE API)、CVSS 评分与 risk_level/CIA 一致性、脱敏与控制字符校验。输出物为纯 JSON（无 Markdown/围栏/解释文字）。
---

# apk-vuln-json-report（APK 漏洞 JSON 报告生成）

## 0. 触发时机与输出位置

### 触发条件（硬性要求）

- **severity ≥ high 的漏洞必须调用本 skill**：每当一条漏洞经 PoC 验证、CVSS 评分 ≥ 7.0（risk_level = high 或 critical）被 `report_finding` 登记后，必须立即对本条 finding 调用本 skill 生成规范 JSON 报告。
- medium/low 漏洞为选做（视任务要求），但 high/critical **不可跳过**。
- **backend / C2 / API / 落地页上的漏洞同样适用**（不要以为只覆盖客户端漏洞）。后端漏洞按"该 APK 客户端所依赖的后端服务缺陷"建模：`layer=network`（或 config/crypto）、`entry_point=network-remote`、`component.name` 取 `api_routes[].route` 或 `backend_endpoints[].url`。
- 任务收尾（goal 达成或任务停止前）planner 必须自查：`list_task_findings` 中每条 severity ≥ high 的 confirmed 漏洞是否都已生成规范 JSON 报告并落盘；缺失则派发补报意图。
- 历史教训：曾有多个任务（NexP2/小闪花/VT Markets/U9XNN6/看片视频/Tato Talk）确认了 50+ 条漏洞却零次调用本 skill，导致报告缺失。不得重演。
- **补报优先级**：当同一任务/同一批次有多条高危+待补报告时，按 §3.0 的顺序（RCE > SQLi > XSS > 信息泄露，能取权限/数据的靠前）先写高优先级条目。

### 输出位置（硬性要求）

生成的 JSON 文件**必须按报告生成日期分目录保存**到：

```
/app/data/apk_vuln_json_reports/{MMDD}/
```

- `{MMDD}` = **报告生成当天**的 4 位月日（两位月 + 两位日，**不加年份**）。例：9 月 10 日生成 → `0910/`；9 月 30 日生成 → `0930/`。
- **文件命名（含 sample_id 前缀 + HHMM 时间后缀）**：
  ```
  {sample_id}_task{task_id}_finding{finding_id}_{HHMM}.json
  ```
  - `sample_id` = 交接 JSON 的 `sample_id`（32 位小写十六进制，与报告内 `sample_id` 字段完全一致）。
  - `task_id` = 任务编号；`finding_id` = `report_finding` 返回的独立记录 id。
  - `HHMM` = **JSON 报告生成那一刻**的 4 位时刻（24 小时制，两位时 + 两位分），例 12:10 → `1210`。
  - 例：`ddc09fb12b262682582959ed7c33fa31_task12_finding52_1210.json`
- 完整路径示例：`/app/data/apk_vuln_json_reports/0930/5a3370b5e166931a6b6a3bf5867a8ac6_task29_finding8198_0945.json`
- **`MMDD` 与 `HHMM` 都用"写文件那一刻"的本地日期/时间**（生成/补报当天），不要用漏洞发现日或任务启动日。
- 日期目录不存在时先 `mkdir -p /app/data/apk_vuln_json_reports/{MMDD}`
- 同时写入平台的 `update_finding_report` 详细报告字段（双写：文件 + 平台）
- ⚠️ **历史文件（2026-09-30 之前生成）仍散落在 `/app/data/apk_vuln_json_reports/` 根目录，不要移动**——它们早于本规则；本规则只约束**当天及以后新生成**的报告。

## 1. 执行步骤

1. **取数**：`list_task_findings(task_id)` 列出全部 confirmed 漏洞；筛选 severity ≥ high（CVSS ≥ 7.0）的条目；对每条用 `get_task_node_detail(task_id, id=finding_node_id)` 取完整 PoC/证据。
2. **调本 skill**：`Skill(name=apk-vuln-json-report, args=<该漏洞的 finding 摘要+证据+交接 JSON 元数据>)`，按下方第 2-5 节规则生成**一个** JSON 对象（每条漏洞一个对象）。
3. **落盘**：将纯 JSON 文本写入文件 `/app/data/apk_vuln_json_reports/{MMDD}/{sample_id}_task{task_id}_finding{finding_id}_{HHMM}.json`（`{MMDD}`=报告生成当天 4 位月日、`{HHMM}`=生成时刻 4 位时刻、`{sample_id}`=交接 JSON 的 sample_id；`mkdir -p` 确保日期目录存在）。
4. **落库**：同时把 JSON 全文经 `update_finding_report(finding_id=<report_finding 返回的独立记录 id>, report=<JSON 全文>, evidence_version=<get_finding_traffic 的 version>)` 写入平台。report 字段内容必须是纯 JSON，不得带 Markdown/代码围栏/解释文字。

## 2. 元数据回填（来自 apk-pentest-handoff JSON）

任务描述中的交接 JSON（schema `apk-pentest-handoff/1.0.0`）字段直接回填，不得编造：

| 报告字段 | 交接来源 |
|---|---|
| `sample_id` | 交接 JSON 的 `sample_id`。规范要求 32 位小写十六进制（MD5）；交接给的是 sha256 时，若样本文件在本地可计算则 `md5sum <APK_PATH>` 重算，否则用交接 `sample_id` 原值并在 `affected[].package.ecosystem_specific.version_source`/`package_name_source` 注明来源为交接记录。`apk_sha256` 回填 `apk_sha256`，`apk_md5` 无证据填 null。 |
| `affected[].package.name` | `package_name`（applicationId） |
| `affected[].package.ecosystem_specific.version_name/version_code` | `version_name` / `version_code` |
| `affected[].package.versions` | `["<version_name>(<version_code>)"]` |
| min_sdk/target_sdk、signing_cert_sha256 | `min_sdk`/`target_sdk`/`signing.cert_sha256` |
| `vulnerability_location.component.name` | 后端漏洞：`api_routes[].route`（如 `/api/users/login`）或 `backend_endpoints[].url`；客户端漏洞：组件类名/Activity |
| `vulnerability_location.layer` | 客户端：manifest/component/code/native/webview/ipc/storage/crypto/config；后端 API：network；TLS/加密配置：config 或 crypto |
| `vulnerability_location.entry_point` | 网络可达的远程缺陷=`network-remote`；仅本机/ADB=local-app/adb；DeepLink=`deeplink`；导出组件=`exported-component`；仅持 APK 可离线提取=`supply-chain` |

## 3. 评分与一致性

### 3.0 报告优先级（同一批次多条高危+待补报告时的处理顺序）

对能**获取权限或数据**的漏洞（命令执行 / SQL 注入 / 后台弱口令 / 越权等），报告/补报按以下优先级排序，先写高优先级：

```
RCE（命令执行/代码执行/未授权写落地）  >  SQLi（SQL 注入）  >  XSS（跨站脚本）  >  信息泄露（含硬编码密钥/PII 泄露/调试模式等）
```

- 同为"获取权限/数据"类时：能直接落地后台/数据库/服务器权限（RCE、后台弱口令、越权读写库）的排在纯读/纯泄露之前。
- 该规则只影响**顺序**，不影响是否必须生成——severity≥high 的 confirmed 漏洞一律必须出报告，优先级低不代表可跳过。
- 无法归入上述四类的其它高危（如 DoS、认证绕过）夹在对应危害级别之间：能提权/取数据的按 RCE/SQLi 侧靠拢，纯可用性/探测类按信息泄露侧靠拢。

- `severity[].score` 用 CVSS:3.1 完整向量；`score_value` 必须与向量复算一致（一位小数）。**CVSS v3.1 的 C/I/A 只有三个值：N、L、H（没有 M/Medium）；UI 只有 N/Y（没有 R）**。
- **`score_value` 必须用官方 CVSS 3.1 公式程序化复算得出，禁止手算估算**。权威实现 = 官方 `cvss` 库（`pip install cvss`，Red Hat python-cvss，已校准 9.8/10.0/8.7 等边界向量）。生成后用 `references/cvss31_check.py` 复算校验（退出码 0 才算过）；`score_value` 与 `risk_level`、`cia` 三者必须自洽。手算极易出错（历史曾出现 6.5/8.2/7.5 与实际 6.1/8.1/7.3 不符，乃至整批 45 个文件偏差），一律以官方库复算为准。
- `database_specific.risk_level` 必须与 `score_value` 区间**严格一致**：critical 9.0–10.0 / high 7.0–8.9 / medium 4.0–6.9 / low 0.1–3.9 / info 0。**以 `score_value` 为准**，不得照抄平台登记的 severity（平台可能标 high，但 CVSS 算出 6.5 时 risk_level 必须写 medium）。二者不匹配即为报告错误。
- `impact_scope.cia.C/I/A` 与向量中的 C/I/A **逐字符一致**（N/L/H）；不得依据未验证推测扩大影响。
- `database_specific.vuln_class` 只用规范枚举（18 项，见下方枚举清单）；CWE 必须经 MITRE API 在线匹配根因（`GET https://cwe-api.mitre.org/api/v1/cwe/weakness/{cweId}`），`problem_types` 与 `cwe_ids` 一一对应；证据不足时标"候选/待确认"且 `confidence` 降为 low/medium。
- `detection_method`：仅静态=static、仅动态验证=dynamic、两者结合=hybrid、人工研判=manual。

## 4. 输出纪律（逐条检查，违反任何一条都会导致校验失败）

### 4.1 顶层结构（14 个字段，顺序固定，不得增删）

```
schema_version, sample_id, aliases, summary, details, severity,
affected, problem_types, vulnerability_location, reproduction,
impact_scope, database_specific, related, upstream
```

**禁止出现的顶层字段**（历史踩坑）：`trigger_precondition`、`reproduction`(字符串)、`impact`、`remediation`、`evidence`、`cwe_ids`、`references`、`generated_at`、`generator`、`notes`、`detection_method`(顶层)。触发前提合并进 `details`；修复建议合并进 `details`；证据合并进 `reproduction.steps[].actual` 或 `details`；CWE 编号只在 `problem_types` 和 `database_specific.cwe_ids` 出现。

### 4.2 必填非空字段（不得为 null/空字符串/空数组）

| 字段 | 要求 |
|---|---|
| `summary` | 8–120 字符，纯文本 |
| `details` | 至少 20 字符 |
| `severity` | 至少 1 项 |
| `severity[].score` | 完整 CVSS 向量字符串 |
| `affected` | 至少 1 项 |
| `problem_types` | 至少 1 项 |
| `reproduction.steps` | 至少 1 项，`evidence_refs` 非空数组 |
| `reproduction.actual_result` | 非空字符串 |
| `impact_scope.preconditions` | 至少 1 项 |
| `impact_scope.impact_description` | **非空字符串**（仅陈述有证据支持的实际影响） |
| `database_specific.cwe_ids` | 至少 1 个编号 |

### 4.3 枚举值（大小写完全一致，不得自创）

| 字段 | 合法值 |
|---|---|
| `severity[].type` | `CVSS_V2` / `CVSS_V3` / `CVSS_V3.1` / `CVSS_V4` |
| CVSS 3.1 向量各度量 | AV=`N/L/A/P`；AC=`L/H`；PR=`N/L/H`；**UI=`N/Y`（只有 N 和 Y，没有 R！）**；S=`U/C`；C/I/A=`N/L/H`。**历史踩坑：曾误用 `UI:R`（不存在），导致向量非法**——需要用户交互时只能用 `UI:Y`（score×1.07），无交互用 `UI:N` |
| `affected[].package.ecosystem` | `Android-APK` / `iOS-IPA` / `HarmonyOS-HAP` / `App-Bundle` |
| `ecosystem_specific.package_format` | `APK` / `IPA` / `HAP` / `AAB` |
| `vulnerability_location.layer` | `manifest` / `component` / `code` / `native` / `config` / `sdk` / `webview` / `network` / `crypto` / `storage` / `ipc` / `other` |
| `vulnerability_location.component.type` | `activity` / `service` / `receiver` / `provider` / `fragment` / `application` / `other` |
| `vulnerability_location.entry_point` | `deeplink` / `exported-component` / `adb` / `local-app` / `network-remote` / `network-local` / `physical` / `supply-chain` / `other` |
| `reproduction.reproducibility` | `always` / `intermittent` / `once` / `unverified` |
| `impact_scope.cia.C/I/A` | `N` / `L` / `H`（**没有 M**） |
| `database_specific.risk_level` | `critical` / `high` / `medium` / `low` / `info` |
| `database_specific.vuln_class` | `组件导出暴露` / `越权访问` / `Intent注入` / `DeepLink漏洞` / `WebView漏洞` / `JSBridge漏洞` / `不安全网络通信` / `证书校验缺陷` / `硬编码敏感信息` / `不安全数据存储` / `加密算法误用` / `Native内存破坏` / `代码注入·动态加载` / `第三方SDK漏洞` / `权限滥用` / `拒绝服务` / `供应链风险` / `其他` |
| `database_specific.detection_method` | `static` / `dynamic` / `hybrid` / `manual` |
| `database_specific.confidence` | `high` / `medium` / `low` |

### 4.4 子结构精确键名（不得多填/少填/改名）

```json
// severity[]
{"type":"CVSS_V3.1","score":"CVSS:3.1/...","score_value":9.8,"source":"team-self"}

// affected[].package
{"ecosystem":"Android-APK","name":"com.xxx","versions":["1.0(1)"],"ecosystem_specific":{...}}

// ecosystem_specific（只允许以下 12 个键，多填一个就报错）
{"package_format":"APK","version_name":"1.0","version_code":1,"apk_md5":null,"apk_sha256":"...","min_sdk":23,"target_sdk":32,"compile_sdk":null,"signing_cert_sha256":null,"sample_file":null,"version_source":"...","package_name_source":"..."}

// problem_types[]
{"problem_type_id":"CWE-306","name":"缺失关键功能的认证","source_name":"CWE","descriptions":[{"lang":"zh","value":"..."},{"lang":"en","value":"Missing Authentication for Critical Function"}]}

// vulnerability_location
{"layer":"network","component":{"type":"other","name":"/api/xxx","extra":"..."},"entry_point":"network-remote"}

// reproduction
{"reproducibility":"always","environment":{"os":"Android","os_version":null,"device_model":null,"root_or_jailbreak":null,"tooling":["curl"],"network_env":"...","prerequisite":"..."},"steps":[{"seq":1,"action":"...","expected":"...","actual":"...","evidence_refs":["step-1"]}],"expected_result":"...","actual_result":"..."}

// impact_scope
{"affected_versions":[],"affected_devices_or_os":null,"preconditions":["..."],"cia":{"C":"H","I":"N","A":"N"},"impact_description":"...","scope_note":null}

// database_specific
{"submission":{"tool_chain":[]},"risk_level":"high","vuln_class":"越权访问","cwe_ids":["CWE-306"],"detection_method":"dynamic","confidence":"high"}
```

### 4.5 格式纪律

- 纯 JSON：无 Markdown、无 ``` 围栏、无任何解释文字；合法 UTF-8；字符串中禁止真实 U+0000–U+001F 控制字符（NUL 数量必须为 0），换行写 `\n` 转义；无尾随逗号。
- 禁止输出系统/个人/内部环境信息（内部任务 ID、用户名、主机名、桌面路径）；命令路径抽象为 `<APK_PATH>`。
- 全部描述用简体中文（技术原文如 URL/类名/包名/CWE 英文名保持原样）。
- `problem_types[].name` 必须是**中文**名称（如"缺失关键功能的认证"），英文放 `descriptions[].lang=en`。
- `related` 和 `upstream` 无则填 `[]`（不得省略字段）。

## 5. 输出前自检清单（逐条过，全部通过才落库）

1. 顶层恰好 14 个字段，顺序与模板一致，无多余/缺失？
2. 无 `trigger_precondition`/`impact`/`remediation`/`evidence`/`cwe_ids`(顶层)/`references`/`generated_at`/`generator`/`notes`/`detection_method`(顶层) 等禁止字段？
3. 所有必填非空字段（§4.2）确实非空？特别是 `impact_scope.impact_description`？
4. 所有枚举值在 §4.3 清单内？C/I/A 只有 N/L/H（无 M）？
5. 子结构键名与 §4.4 精确一致？`ecosystem_specific` 无多余键？
6. CVSS 向量复算 → `score_value` 一致？`cia` 与向量逐字符一致？**`database_specific.risk_level` 必须与 `score_value` 的区间严格匹配**（见下，二者不一致即为错误，必须改其一）：
   - critical = 9.0–10.0
   - high = 7.0–8.9
   - medium = 4.0–6.9
   - low = 0.1–3.9
   - info = 0
   > ⚠️ 高频踩坑：平台登记 severity（如某 finding 标 high）≠ CVSS 分数区间。**以 `score_value` 为准**定 `risk_level`，不要照抄平台登记的 severity。例：C:L/I:L/A:N = 6.5 → risk_level 必须是 medium，不能写 high。
7. `problem_types[].problem_type_id` 与 `database_specific.cwe_ids` 完全对应？
8. `reproduction.steps[].seq` 连续、`evidence_refs` 非空？
9. 全文 NUL 字节 = 0？无 U+0000–U+001F 控制字符？
10. 无系统/个人/内部环境信息？路径已抽象？
11. **已运行 `references/cvss31_check.py` 程序化复算校验且退出码为 0**（score_value/risk_level/vuln_class/cia 全部一致）？——这是第 6 项的机器校验，**必跑**，手算不算数。

## 6. 参考文件

- `references/spec-v1.0.0.md` — 完整字段定义、枚举、模板（生成前必读）。
- `references/example1.json` — 已脱敏的完整后端漏洞样例（network 层 + CWE-306/434 + dynamic）。**生成前对照此样例确认结构一致**。
- `references/cvss31_check.py` — **CVSS 3.1 评分一致性校验器（已用官方 `cvss` 库 v3.6 校准）**。生成报告后**必须运行**它对 score_value/risk_level/vuln_class/cia/control-chars 做程序化复算校验，**禁止手算 score_value**：
  - 校验整批报告：`python3 /app/skills/apk-vuln-json-report/references/cvss31_check.py /app/data/apk_vuln_json_reports`（退出码 0=全过，1=有问题）
  - 校验单向量：`python3 .../cvss31_check.py "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N"`
  - 依赖 `pip install cvss`（Red Hat 官方 python-cvss）。库缺失时脚本会显著告警并回退内置近似公式（个别 S:C 向量可能差 0.1–0.4），此时以告警提示为准、应安装官方库复跑。
  - 历史教训：本目录曾出现 45 个文件 score_value 手算错误（如 9.6 实为 10.0、10.0 实为 8.7），全部由该校验器依据官方库一键修正。**score_value 一律以官方库复算为准**。
- `references/handoff-requirement-template.txt` — 「apk backend pentest」任务模板：新建 APK 渗透任务时，把其中「漏洞报告硬性要求」段落并入任务 description/goal（对应平台任务模板 apk backend pentest），即可保证 new 任务自动产出 JSON 报告。

## 7. 如何保证【未来新建任务】自动调用本 skill（固化机制，三层兜底）

> 平台限制：**任务的 skill 白名单在任务启动时锁定**（历史任务 worker 看不到后续新增/更新的 skill，task17-20 即因此漏报）。因此不能只依赖"skill 存在"，要把"必须生成 JSON 报告"这条规则**写进任务启动时就必然被读到的地方**，并准备 skill 不可用时的兜底路径。

### 第 1 层（最高优先）：写进交接 JSON / 任务描述（任务启动即存在、必然被读）

APK 任务的描述就是交接 JSON（`apk-pentest-handoff/1.0.0`）+ 工作建议。**新建任务时，在交接 JSON 的 `notes` 字段或紧随其后的"工作建议"里必须包含这条硬性要求**（模板，照抄即可）：

```
【漏洞报告硬性要求】本任务每确认一条 severity≥high（CVSS≥7.0）的漏洞（report_finding 之后），
必须立即生成符合《APK 漏洞 JSON 报告生成规范 v1.0.0》的 JSON 报告：
1) 优先调用 Skill(name=apk-vuln-json-report) 生成；
2) 若该 skill 不在当前可用技能列表（报 unknown skill），则直接读取
   /app/skills/apk-vuln-json-report/references/spec-v1.0.0.md 与 example1.json，按规范手工生成等价 JSON；
3) 将 JSON 写入 /app/data/apk_vuln_json_reports/{MMDD}/{sample_id}_task{task_id}_finding{finding_id}_{HHMM}.json
   （{MMDD}=报告生成当天 4 位月日、{HHMM}=生成时刻 4 位时刻、{sample_id}=交接 JSON 的 sample_id，
     例 0930/5a3370b5e166931a6b6a3bf5867a8ac6_task29_finding8198_0945.json，先 mkdir -p 该日期目录），
   并同步 update_finding_report 落库。
生成前用交接 JSON 的 sample_id/package/version/端点/路由 直接回填，
vulnerability_location.component.name 取 api_routes[].route 或 backend_endpoints[].url。
任务收尾前自查：所有 high/critical confirmed 漏洞是否都已生成 JSON 报告并落盘。
```

> 这一层不依赖 skill 白名单，是最可靠的一层。只要交接 JSON 里写了，worker/planner 启动就读到。

### 第 2 层：skill 触发描述（在可用列表时自动命中）

skill 的 front-matter `description` 已写明触发条件（"确认 high/critical 漏洞后必须调用"）。当 `apk-vuln-json-report` 在新任务的白名单内时，worker 在 `report_finding` 后会按描述自动触发。

### 第 3 层：planner 收尾自查（兜底校验）

任务 goal 达成 / 停止前，planner 必须 `list_task_findings` 核对：每条 severity≥high 的 confirmed 漏洞是否已有对应 `/app/data/apk_vuln_json_reports/{task_id}_finding{id}.json` 文件 + 平台 report 字段；缺失则补发意图。

### 编排层（Auto agent）额外动作

- **spawn_task 新建 APK 任务时**：把第 1 层那段硬性要求并入 `goal`/`description` 传给子任务（编排 agent 无法直接改 skill 白名单，但能写任务描述）。
- **发现漏报时**：`add_task_hint` 注入"必须调用 apk-vuln-json-report 并落盘 /app/data/apk_vuln_json_reports/{MMDD}/{sample_id}_task{task_id}_finding{finding_id}_{HHMM}.json"的提示（worker/planner 下轮会读到）。
- **skill 不可用的兜底**：即使 skill 不在白名单，worker 仍可直接 `Read` `/app/skills/apk-vuln-json-report/references/spec-v1.0.0.md` 与 `example1.json` 手工生成等价 JSON（task12 worker 已验证此路径可行）。references 目录是普通文件，不受 skill 白名单限制。

### 一句话总结

**把"high+ 漏洞必须生成 JSON 报告并落盘 /app/data/apk_vuln_json_reports/{MMDD}/{sample_id}_task{task_id}_finding{finding_id}_{HHMM}.json（按当天日期分目录 + sample_id 前缀 + HHMM 时间后缀）"写进每个 APK 任务的交接 JSON/描述（第 1 层），skill 描述（第 2 层）与 planner 收尾自查（第 3 层）双重兜底，skill 不可用时直接读 references 手工生成。** 这样无论 skill 是否进白名单，报告都会产出并落到正确的日期目录。
